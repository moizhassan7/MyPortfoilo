<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Agha</title>
</head>
<link rel="stylesheet" href="./style.css">

<body>
    <nav>
        <div class="left">
            <!-- <img src="./riccardo-trimeloni-lc5iIZ7UO1w-unsplash.jpg" alt=""> -->
            <h1>Digital Agha</h1>
            <li>Categories</li>
        </div>
        <div class="right">
            <input list="courses" placeholder="Search for everything">
            <button>Search</button>
            <button>Login</button>
            <button value="Signup">Sign up</button>
        </div>

        <datalist id="courses">
            <option value="Graphic Design">
            <option value="Web Development">
            <option value="Social Media Markting">
            <option value="UI/UX Design">
        </datalist>
    </nav>
    <section class="section1">

        <div class="heading">
            <h1>Learning that gets you</h1><br>
            <p> Skills for your present (and your future). Get started with us.</p>

        </div>
    </section>
    <section class="section2">
        <h1>
            A broad selection of courses
        </h1>
        <div class="container1">
            <h1>Expand your career opportunities</h1>
            <div class="cards">
                <a href="#" id="card1" class="card"><img src="./riccardo-trimeloni-lc5iIZ7UO1w-unsplash.jpg" alt=""></a>
                <a href="#" id="card2" class="card"><img src="./imge2.jpg" alt=""></a>
                <a href="#" id="card3" class="card"><img src="./imge2.jpg" alt=""></a>
                <a href="#" id="card4" class="card"><img src="./First Figma file.png" alt=""></a>
            </div>
            <div class="cardsnames">
                <a href="" target="_blank">Web Development</a>
                <a href="" target="_blank">Graphic Designing</a>
                <a href="" target="_blank">Social Media Markting</a>
                <a href="" target="_blank">UX/UI design</a>
            </div>
            <div class="cards">
                <a href="#" id="card1" class="card"><img src="./riccardo-trimeloni-lc5iIZ7UO1w-unsplash.jpg" alt=""></a>
                <a href="#" id="card2" class="card"><img src="./imge2.jpg" alt=""></a>
                <a href="#" id="card3" class="card"><img src="./imge2.jpg" alt=""></a>
                <a href="#" id="card4" class="card"><img src="./imge3.jpg" alt=""></a>
            </div>
            <div class="cardsnames">
                <a href="" target="_blank">Web Dev</a>
                <a href="" target="_blank">Graphic Design</a>
                <a href="" target="_blank">Social Media Markting</a>
                <a href="" target="_blank">UX/Ui design</a>
            </div>
        </div>
    </section>
    <section class="section3">
        <div class="student">
            <h1>500+</h1>
            <h2>Students</h2>
        </div>
        <div class="quality">
            <h1>A+</h1>
            <h2>Quality</h2>
        </div>
    </section>
    <div class="section6">
        <div class="headings">
            <h1>Meet the team</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus quidem perspiciatis voluptas ab?
            </p>
        </div>
        <div class="container2">
            <div class="boxes"><img src="./img_app-team_01.png" alt="">
                <h1>Agha Taha</h1><span style=" color: #00000080;">Founder &
                    CEO</span>
            </div>
            <div class="boxes"><img src="./img_app-team_02.png" alt="">
                <h1>Talha Mehmood</h1><span style=" color: #00000080;">Co-Founder</span>
            </div>
            <div class="boxes"><img src="./321542484_399481619032840_7417632021815561859_n.jpg" alt="">
                <h1>Moiz Hassan</h1><span style=" color: #00000080;">Software Engineer</span>
            </div>
            <div class="boxes"><img src="./img_app-team_04.png" alt="">
                <h1>Sumeal Sherif</h1><span style=" color: #00000080;">Junior
                    Developer</span>
            </div>
            <div class="boxes"><img src="./img_app-team_05.png" alt="">
                <h1>Peace Steve</h1><span style=" color: #00000080;">Markting and
                    sales</span>
            </div>
            <div class="boxes"><img src="./img_app-team_06.png" alt="">
                <h1>Jordan Noman</h1><span style=" color: #00000080;">Junior
                    Developer</span>
            </div>

        </div>
    </div>
    </section>
    <div class="section7">
        <div class="text-container4">
            <h1>What they say about us</h1>
            <div class="vertical-line"></div>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, totam accusantium numquam quos
                incidunt, assumenda quasi atque fuga id repellendus facilis fugiat dolores obcaecati. Ad molestias
                cupiditate similique expedita ducimus!
            </p>
        </div>
        <div class="boxes-container">
            <div class="boxes-list"><img src="./321542484_399481619032840_7417632021815561859_n.jpg" alt="">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam delectus laudantium necessitatibus
                    ipsam quas provident! Aliquam maxime tempora quas repudiandae quia consequuntur vero veritatis
                    temporibus unde assumenda modi molestias magnam qui, amet eius explicabo quae.</p>
                <h3>Moiz Hassan</h3> <span>Software Engineer</span>
            </div>
            <div class="boxes-list"><img src="./img_app-team_06.png" alt="">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam delectus laudantium necessitatibus
                    ipsam quas provident! Aliquam maxime tempora quas repudiandae quia consequuntur vero veritatis
                    temporibus unde assumenda modi molestias magnam qui, amet eius explicabo quae.</p>
                <h3>Jordan Noman</h3> <span>Junior Developer</span>
            </div>
            <div class="boxes-list"><img src="./img_app-team_05.png" alt="">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam delectus laudantium necessitatibus
                    ipsam quas provident! Aliquam maxime tempora quas repudiandae quia consequuntur vero veritatis
                    temporibus unde assumenda modi molestias magnam qui, amet eius explicabo quae.</p>
                <h3>Peace Steve</h3> <span>Markting and sales</span>
            </div>
        </div>

    </div>
    <div class="section8">
        <div class="left2">
            <h1>
                Contact Us
            </h1>
            <span>
                Email : example@gmail.com <br> <br>
                Phone Number : 123-456-789
            </span>

        </div>
        <div class="right2">
            <input type="email" name="" id="" placeholder="Your best email...">
            <button>Submit</button>

        </div>
    </div>
</body>

</html>
<?php
?>